var express=require('express');
var app=express();
var fs=require("fs");
var empl={"emp4":{
	"id": 104,
	"name": "john",
	"designation": "developer",
	"address": "anna nagar"
}
}
app.post('/addEmp',function(req,res){
	//first read existing data
	fs.readFile(__dirname+"/"+"emp.json",'utf8',function(err,data){
		data=JSON.parse(data);
		data["emp4"]=empl["user4"];
		console.log(data);
res.end(JSON.stringify(data));});})
var server=app.listen(5000,function(){
	var host=server.address().address
	var port=server.address().port
	
console.log("App listening at http://%s%s",host,port)})