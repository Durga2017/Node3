var express = require('express');
var mysqlcon = require('mysql');
var router = express.Router();
 
//MySQL
var sqlInfo = {
  host: 'localhost', 
  user: 'root',
  password: '', 
  database: 'Demo'
}
/* GET home page. */
router.get('/', function(req, res, next) {
// connect to MySQL server
  var client = mysqlcon.createConnection(sqlInfo);
  client.connect();
  // Perform query and wait for results
  client.query( "SELECT * FROM mytable ORDER BY E_id", function(err, row, fields) {
    // Done with the connection
    client.end();
    // Handle error
    if (err) throw err;
    else {
      // We got a result: render it
      console.log(row);
      res.render("index", { title:'Mysql Data Fetch',userresults: row});
    }
  });
});
module.exports = router;