var express=require('express');
var app=express();
var fs=require('fs');
app.get('/listEmp',function(req,res){
	fs.readFile(__dirname+"/"+"emp.json",'utf8',function(err,data){
		console.log(data);
		res.end(data);
	});
})
var server=app.listen(5000,function(){
	var host=server.address().address
	var port=server.address().port
	console.log("App listening at HTTP: %s%s", host,port)
})
