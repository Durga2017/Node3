var express=require("express");
var http = require('http'),
   mysql = require("mysql");
	

   
var connection = mysql.createConnection({
host: 'localhost',
user: 'root',
database: 'Demo'
});
var app=express();

http.createServer(function (request, response) 
{
   request.on('end', function () 
   {   
      connection.query('SELECT * FROM mytable ', function(error, rows, fields)
      {
         response.writeHead(200);

         response.end(JSON.stringify(rows));
      });
   });

})
app.listen(9001);